# CAIU-SENEGAL-OFFICIEL

Projet source Android de la boutique CAIU.

- Application Android : `sn.caiu.senegalofficiel`
- Interface en français et prix en FCFA
- Commandes WhatsApp : +221 77 190 87 85
- Le logo fourni est inclus sans modification dans `app/src/main/assets/caiu-logo.png`

Ce ZIP contient le code source, pas un APK/AAB compilé. Pour produire une application installable, le projet doit être compilé avec Android Gradle Plugin dans un environnement Android compatible.
